﻿var SkytunesController = function($scope, $http, player) {
    $http.get("~/Scripts/artists.json")
    .then(function(response) {
        $scope.artists= response.data;
    });
    $scope.player = player;
}

SkytunesController.$inject = ['$scope', '$http', 'player'];
