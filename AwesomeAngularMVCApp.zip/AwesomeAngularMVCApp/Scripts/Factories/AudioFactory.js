﻿var audio = function($document) {
	var audio = $document[0].createElement('audio');
    return audio;
}

audio.$inject = ['$document'];
