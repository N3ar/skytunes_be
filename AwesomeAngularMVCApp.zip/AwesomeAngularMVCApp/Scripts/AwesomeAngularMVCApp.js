﻿var AwesomeAngularMVCApp = angular.module('AwesomeAngularMVCApp', ['ngRoute']);

AwesomeAngularMVCApp.controller('LandingPageController', LandingPageController);
AwesomeAngularMVCApp.controller('LoginController', LoginController);
AwesomeAngularMVCApp.controller('RegisterController', RegisterController);

AwesomeAngularMVCApp.controller('SkytunesController', SkytunesController);

AwesomeAngularMVCApp.factory('LoginFactory', LoginFactory);
AwesomeAngularMVCApp.factory('RegistrationFactory', RegistrationFactory);

AwesomeAngularMVCApp.factory('audio', audio);
AwesomeAngularMVCApp.factory('player', player);


AwesomeAngularMVCApp.factory('AuthHttpResponseInterceptor', AuthHttpResponseInterceptor);

var configFunction = function ($routeProvider, $httpProvider) {
    $routeProvider.
        when('/login', {
            templateUrl: '/Account/Login',
            controller: LoginController
        })
        .when('/register', {
            templateUrl: '/Account/Register',
            controller: RegisterController
        }) //Following is for Stunes
        .when('/userPage', {
            templateUrl: '/userHome/UserHome',
            controller: SkytunesController
        })
        .when('/uploadMusic', {
            templateUrl: '/userHome/UploadMusic',
            controller: SkytunesController
        });


    $httpProvider.interceptors.push('AuthHttpResponseInterceptor');
}
configFunction.$inject = ['$routeProvider', '$httpProvider'];

AwesomeAngularMVCApp.config(configFunction);