﻿var SkyTunes = angular.module('SkyTunes', ['ngRoute']);

SkyTunes.controller('LandingPageController', LandingPageController);
SkyTunes.controller('LoginController', LoginController);
SkyTunes.controller('RegisterController', RegisterController);

SkyTunes.controller('SkytunesController', SkytunesController);

SkyTunes.factory('LoginFactory', LoginFactory);
SkyTunes.factory('RegistrationFactory', RegistrationFactory);

SkyTunes.factory('audio', audio);
SkyTunes.factory('player', player);


SkyTunes.factory('AuthHttpResponseInterceptor', AuthHttpResponseInterceptor);

var configFunction = function ($routeProvider, $httpProvider) {
    $routeProvider.
        when('/login', {
            templateUrl: '/Account/Login',
            controller: LoginController
        })
        .when('/register', {
            templateUrl: '/Account/Register',
            controller: RegisterController
        }) //Following is for Stunes
        .when('/userPage', {
            templateUrl: '/userHome/UserHome',
            controller: SkytunesController
        })
        .when('/uploadMusic', {
            templateUrl: '/userHome/UploadMusic',
            controller: SkytunesController
        });


    $httpProvider.interceptors.push('AuthHttpResponseInterceptor');
}
configFunction.$inject = ['$routeProvider', '$httpProvider'];

SkyTunes.config(configFunction);