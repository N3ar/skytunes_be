﻿using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNet.Identity;
using MySql.AspNet.Identity;

namespace SkyTunes.Models
{
	// You can add profile data for the user by adding more properties to your ApplicationUser class, please visit http://go.microsoft.com/fwlink/?LinkID=317594 to learn more.
	public class ApplicationUser : IdentityUser
	{
		public async Task<ClaimsIdentity> GenerateUserIdentityAsync(UserManager<ApplicationUser> manager)
		{
			// Note the authenticationType must match the one defined in CookieAuthenticationOptions.AuthenticationType
			var userIdentity = await manager.CreateIdentityAsync(this, DefaultAuthenticationTypes.ApplicationCookie);
			// Add custom user claims here
			return userIdentity;
		}
	}

	//public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
	//{
	//    public ApplicationDbContext()
	//        : base("DefaultConnection", throwIfV1Schema: false)
	//    {
	//    }

	//    public static ApplicationDbContext Create()
	//    {
	//        return new ApplicationDbContext();
	//    }
	//}

	//	[DbConfigurationType(typeof(MySql.Data.Entity.MySqlEFConfiguration))]
	//	public class ApplicationDbContext : DbContext
	//	{
	//		
	//		public ApplicationDbContext() : base("Server=localhost:3306;Database=tutorial_database;Uid=admin;Pwd=admin_pass;")
	//		{
	//			Database.SetInitializer<ApplicationDbContext>(new CreateDatabaseIfNotExists<ApplicationDbContext>());
	//
	//		}
	//		public DbSet<ApplicationUser> ApplicationUsers { get; set; }
	//	
	//
	//		public static ApplicationDbContext Create()
	//		{
	//			var context = new ApplicationDbContext();
	//			context.Database.CreateIfNotExists();
	//			return context;
	//		}
	//
	//	}
}