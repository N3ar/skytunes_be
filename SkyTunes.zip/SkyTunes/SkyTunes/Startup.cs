﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(SkyTunes.Startup))]
namespace SkyTunes
{
	public partial class Startup
	{
		public void Configuration(IAppBuilder app)
		{
			ConfigureAuth(app);
		}
	}
}
